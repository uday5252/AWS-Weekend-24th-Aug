export const PORT = process.env.PORT || 5555;

export const mongoDBURL =
  'mongodb+srv://uday:Welcome%401234@books-store-mern.csxtwvw.mongodb.net/books-collection?retryWrites=true&w=majority&appName=books-store-mern';
// Please create a free database for yourself.
// This database will be deleted after tutorial